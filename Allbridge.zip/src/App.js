import logo from './logo.svg';
import './App.css';
import  Landing  from './layouts/Landing/Landing';
import Footer from './layouts/Footer/Footer';



function App() {
  return (
    <div className="App">
      <Landing/>
      <Footer/>
    </div>
  );
}

export default App;
